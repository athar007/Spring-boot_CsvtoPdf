package com.evcharging.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvChargingStationApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvChargingStationApplication.class, args);
	}

}
