package com.fujitsu.csvtopdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCsvToPdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
